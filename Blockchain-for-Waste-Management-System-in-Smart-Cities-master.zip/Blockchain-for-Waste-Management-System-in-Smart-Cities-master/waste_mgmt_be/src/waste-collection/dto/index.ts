export * from './waste-collection.dto';
