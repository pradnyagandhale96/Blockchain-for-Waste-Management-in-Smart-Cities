Steps to run the project 

backend ------- npm run start:dev <br>
frontend ----------- npm run dev